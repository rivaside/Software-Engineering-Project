﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.StudentID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FirstNametxt = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Addresstxt = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Ziptxt = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SSNtxt = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DOBtxt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Phonetxt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Citytxt = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LastNametxt = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.AddBtn = New System.Windows.Forms.Button()
        Me.Close = New System.Windows.Forms.Button()
        Me.Password = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'StudentID
        '
        Me.StudentID.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentID.ForeColor = System.Drawing.SystemColors.ControlText
        Me.StudentID.Location = New System.Drawing.Point(164, 32)
        Me.StudentID.Margin = New System.Windows.Forms.Padding(2)
        Me.StudentID.Name = "StudentID"
        Me.StudentID.Size = New System.Drawing.Size(167, 29)
        Me.StudentID.TabIndex = 3
        Me.StudentID.Text = "Enter Student ID"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Crimson
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(40, 27)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 34)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Student ID:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FirstNametxt
        '
        Me.FirstNametxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FirstNametxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FirstNametxt.Location = New System.Drawing.Point(164, 88)
        Me.FirstNametxt.Margin = New System.Windows.Forms.Padding(2)
        Me.FirstNametxt.Name = "FirstNametxt"
        Me.FirstNametxt.Size = New System.Drawing.Size(167, 29)
        Me.FirstNametxt.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Crimson
        Me.Label2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(40, 83)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 34)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "First Name:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Addresstxt
        '
        Me.Addresstxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Addresstxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Addresstxt.Location = New System.Drawing.Point(164, 140)
        Me.Addresstxt.Margin = New System.Windows.Forms.Padding(2)
        Me.Addresstxt.Name = "Addresstxt"
        Me.Addresstxt.Size = New System.Drawing.Size(167, 29)
        Me.Addresstxt.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Crimson
        Me.Label3.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(40, 135)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(105, 34)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Address:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Ziptxt
        '
        Me.Ziptxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Ziptxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Ziptxt.Location = New System.Drawing.Point(164, 190)
        Me.Ziptxt.Margin = New System.Windows.Forms.Padding(2)
        Me.Ziptxt.Name = "Ziptxt"
        Me.Ziptxt.Size = New System.Drawing.Size(167, 29)
        Me.Ziptxt.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Crimson
        Me.Label4.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(40, 185)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 34)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Zip:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SSNtxt
        '
        Me.SSNtxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SSNtxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SSNtxt.Location = New System.Drawing.Point(164, 242)
        Me.SSNtxt.Margin = New System.Windows.Forms.Padding(2)
        Me.SSNtxt.Name = "SSNtxt"
        Me.SSNtxt.Size = New System.Drawing.Size(167, 29)
        Me.SSNtxt.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Crimson
        Me.Label5.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(40, 237)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 34)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "SSN:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DOBtxt
        '
        Me.DOBtxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOBtxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DOBtxt.Location = New System.Drawing.Point(484, 242)
        Me.DOBtxt.Margin = New System.Windows.Forms.Padding(2)
        Me.DOBtxt.Name = "DOBtxt"
        Me.DOBtxt.Size = New System.Drawing.Size(167, 29)
        Me.DOBtxt.TabIndex = 21
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Crimson
        Me.Label6.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(360, 237)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(105, 34)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "DOB:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Phonetxt
        '
        Me.Phonetxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Phonetxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Phonetxt.Location = New System.Drawing.Point(484, 190)
        Me.Phonetxt.Margin = New System.Windows.Forms.Padding(2)
        Me.Phonetxt.Name = "Phonetxt"
        Me.Phonetxt.Size = New System.Drawing.Size(167, 29)
        Me.Phonetxt.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Crimson
        Me.Label7.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(360, 185)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 34)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Phone #:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Citytxt
        '
        Me.Citytxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Citytxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Citytxt.Location = New System.Drawing.Point(484, 140)
        Me.Citytxt.Margin = New System.Windows.Forms.Padding(2)
        Me.Citytxt.Name = "Citytxt"
        Me.Citytxt.Size = New System.Drawing.Size(167, 29)
        Me.Citytxt.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Crimson
        Me.Label8.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(360, 135)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(105, 34)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "City:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LastNametxt
        '
        Me.LastNametxt.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LastNametxt.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LastNametxt.Location = New System.Drawing.Point(484, 88)
        Me.LastNametxt.Margin = New System.Windows.Forms.Padding(2)
        Me.LastNametxt.Name = "LastNametxt"
        Me.LastNametxt.Size = New System.Drawing.Size(167, 29)
        Me.LastNametxt.TabIndex = 15
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Crimson
        Me.Label9.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(360, 83)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(105, 34)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Last Name:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'AddBtn
        '
        Me.AddBtn.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddBtn.Location = New System.Drawing.Point(189, 300)
        Me.AddBtn.Margin = New System.Windows.Forms.Padding(2)
        Me.AddBtn.Name = "AddBtn"
        Me.AddBtn.Size = New System.Drawing.Size(110, 29)
        Me.AddBtn.TabIndex = 23
        Me.AddBtn.Text = "Add"
        Me.AddBtn.UseVisualStyleBackColor = True
        '
        'Close
        '
        Me.Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Close.Location = New System.Drawing.Point(402, 300)
        Me.Close.Margin = New System.Windows.Forms.Padding(2)
        Me.Close.Name = "Close"
        Me.Close.Size = New System.Drawing.Size(110, 29)
        Me.Close.TabIndex = 24
        Me.Close.Text = "Close"
        Me.Close.UseVisualStyleBackColor = True
        '
        'Password
        '
        Me.Password.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Password.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Password.Location = New System.Drawing.Point(484, 37)
        Me.Password.Margin = New System.Windows.Forms.Padding(2)
        Me.Password.Name = "Password"
        Me.Password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Password.Size = New System.Drawing.Size(167, 29)
        Me.Password.TabIndex = 25
        Me.Password.Text = "Enter Password"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Crimson
        Me.Label10.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(360, 32)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(105, 34)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "Password:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(496, 273)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(143, 13)
        Me.Label11.TabIndex = 27
        Me.Label11.Text = "DOB Format: YYYY/MM/DD"
        '
        'NewStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(688, 355)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Password)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Close)
        Me.Controls.Add(Me.AddBtn)
        Me.Controls.Add(Me.DOBtxt)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Phonetxt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Citytxt)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.LastNametxt)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.SSNtxt)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Ziptxt)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Addresstxt)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.FirstNametxt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.StudentID)
        Me.Controls.Add(Me.Label1)
        Me.Name = "NewStudent"
        Me.Text = "New Student"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents StudentID As TextBox
    Friend WithEvents Label1 As Label
    Public WithEvents FirstNametxt As TextBox
    Friend WithEvents Label2 As Label
    Public WithEvents Addresstxt As TextBox
    Friend WithEvents Label3 As Label
    Public WithEvents Ziptxt As TextBox
    Friend WithEvents Label4 As Label
    Public WithEvents SSNtxt As TextBox
    Friend WithEvents Label5 As Label
    Public WithEvents DOBtxt As TextBox
    Friend WithEvents Label6 As Label
    Public WithEvents Phonetxt As TextBox
    Friend WithEvents Label7 As Label
    Public WithEvents Citytxt As TextBox
    Friend WithEvents Label8 As Label
    Public WithEvents LastNametxt As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents AddBtn As Button
    Friend WithEvents Close As Button
    Friend WithEvents Password As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
End Class
